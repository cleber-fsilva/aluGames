package br.com.alura.alugames.modelo

data class InfoApiShark(val title:String, val thumb:String)
